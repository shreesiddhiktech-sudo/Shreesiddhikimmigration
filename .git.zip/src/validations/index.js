module.exports = {
  ...require("./visaCategory.validator"),
  ...require("./country.validator"),
  ...require("./auth.validation"),
};
